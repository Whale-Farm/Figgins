      <?php


 /**

 *
 * Footer Template
 *
 * @package Figgins

 */

 ?>

 
  <!-- ====== Contact Us Section ====== -->
      <section class="contact-us-sect" id="cntct-sect">

         <div class="container">

          <div class="row section-title text-center">
             <h2 class="section-head pb-5 ">Contact Us</h2>
          </div>

          <div class="row">

            <div class="col-12  figgins-contact-form">


              <?php echo do_shortcode('[contact-form-7 id="39" title="Free Estimate Form"]'); ?>

              <!-- <div class="form-row">
                        <div class="form-group col-md-6">
                           <label for="fname" class="p-0 m-0"> First Name</label>
                           <input type="text" class="form-control" id="homeFName" >
                        </div>
                        <div class="form-group col-md-6">
                           <label for="lname" class="p-0 m-0"> Last Name</label>
                           <input type="text" class="form-control" id="homeLName" >
                        </div>
              </div> -->


             <!--  <div class="form-row">
                 <div class="form-group col-md-6">
                    <label for="phone" class="p-0 m-0">Phone</label>
                    <input type="text" class="form-control" id="homePhone" > 
                 </div>
                 <div class="form-group col-md-6">
                    <label for="email" class="p-0 m-0">Email</label>
                    <input type="email" class="form-control" id="homeEmail" > 
                 </div>
              </div> -->

              <!-- Need to embed -->
             <!--  <div class="form-row">
                 <div class="form-group col-md-4">
                    <label for="inputService" class="p-0 m-0">Select Service</label>
                    <select id="inputService" class="form-control">
                       <option selected>Choose Service</option>
                       <option> Coolling Service</option>
                       <option> AC Installation </option>
                       <option> AC Repair</option>
                       <option> AC Change</option>
                    </select>
                 </div>
                 <div class="form-group col-md-4">
                    <label for="preDate" class="p-0 m-0">Preferred Day of Service</label>
                    <input type="text" class="form-control" id="prefDate" > 
                 </div>
                 <div class="form-group col-md-4">
                    <label for="preTimeinput" class="p-0 m-0">Preferred Time of Service</label>
                    <input type="text" class="form-control" id="prefTime" > 
                 </div>
              </div> -->
              <!-- End Need to embed -->

            <!--   <div class="form-group">
                 <label for="help" class="p-0 m-0">What Can We Help With You?</label>
                 <textarea class="form-control" id="homeHelp" rows="5"  > </textarea>
              </div>
              <button type="submit" class="btn form-submit-btn mt-lg-4">Get Free Estimate</button> -->



            </div>

           </div> 

         </div>

      </section>   



     <footer id="footer">
         <div class="container">
            <div class="row">
               <div class="col-12 ">

                  <?php 
                    $args= array(
                        'theme_location'  => 'footer-menu',
                        'menu'            => '',
                        'container'       => '',
                        'container_class' => false,
                        'container_id'    => '',
                        'menu_class'      => ' nav justify-content-center footer-ul',
                        'menu_id'         => ' ',
                        'echo'            => false,
                        'fallback_cb'     => 'fall_back_menu',
                        'before'          => '',
                        'after'           => '',
                        'link_before'     => '',
                        'link_after'      => '',
                        'depth'           => 0,
                        'walker'          => ''
                    );

                  echo wp_nav_menu( $args );
                    

                  ?> 

               </div>
               <div class="col-12 footer-logo text-center mt-5 pt-4">
                  <img src="<?php echo get_template_directory_uri();?>/images/footer-logo.png" alt="" >
               </div>
            </div>
            <div class="row footer-address mt-3">
               <?php if ( is_active_sidebar( 'footer_addr_phn' ) ) : 
                  
                  dynamic_sidebar( 'footer_addr_phn' );
                  
               endif; ?>
               
            </div>
            <div class="row ">
               <div class="footer-social-icons  ">

                  <?php if ( is_active_sidebar( 'footer_social' ) ) : 
                     
                     dynamic_sidebar( 'footer_social' );
                     
                  endif; ?> 
                  
               </div>
            </div>
         </div>
         <div class="container-fuild ">
            <div class="row pt-2 copyright-main-div text-center">
               <div class="col-12">
                  <p> Day Heating · CCB 1090 </p>
               </div>
               <div class="col-12 copyright-text">
                  <?php if ( is_active_sidebar( 'copyright_text' ) ) : 
                     
                     dynamic_sidebar( 'copyright_text' );
                     
                  endif; ?>
                <!--   <p>2021 All Rights Reserved. <a href="">Figgins Heating and Air  </a></p> -->
               </div>
            </div>
         </div>
      </footer>
      <script src="<?php echo get_template_directory_uri();?>/js/jquery-3.5.slim.min.js"  ></script> 
      <script src="<?php echo get_template_directory_uri();?>/js/popper.min.js"  ></script>
      <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
      <script src="<?php echo get_template_directory_uri();?>/js/bootstrap.min.js"  ></script>   
      <script src="<?php echo get_template_directory_uri();?>/js/jquery-ui.min.js"  ></script>   
      <script src="<?php echo get_template_directory_uri();?>/js/bootnavbar.js" ></script>   
      <script src="<?php echo get_template_directory_uri();?>/js/timepicker.js"  ></script>   
      <!-- ==== Carousal  -->
      <script src="<?php echo get_template_directory_uri();?>/js/owl.carousel.min.js"></script>
      <script src="<?php echo get_template_directory_uri();?>/js/custom-js.js"></script> 
   </body>
</html>