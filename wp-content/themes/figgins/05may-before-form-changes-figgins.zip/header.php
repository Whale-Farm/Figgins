<!DOCTYPE html>
<html lang="en">
   <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1 shrink-to-fit=no">
      <title> Figgins Website  </title> 
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" integrity="sha384-wvfXpqpZZVQGK6TAh5PVlGOfQNHSoD2xbE+QkPxCAFlNEevoEH3Sl0sibVcOQVnN" crossorigin="anonymous">
      <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/fontawesome-4.7.min.css"  >
      <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/bootstrap.css"  >
      <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/jquery-ui.min.css"  >
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"  >

      <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/timepicker.css"  >
      <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/css/style.css">
      <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/css/wp-style-custom.css">
      <link rel="stylesheet" href="<?php echo get_template_directory_uri();?>/css/bootnavbar.css">
      <!-- Owl Carousal Files -->
      <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/css/owl.carousel.css">
      <link rel="stylesheet" type="text/css" href="<?php echo get_template_directory_uri();?>/css/owl.theme.default.min.css">
   </head>
   <body class="<?php body_class();?>">

         <?php if(function_exists('wp_body_open() ')){
          
          wp_body_open();

         }
         ?>
      <header id="header" class="header w-100">
         <div class="container">
            <div class="row pt-3 pt-sm-0 pb-3 pb-lg-0">
               <div class="col">
                  <nav class="navbar navbar-expand-lg navbar-dark bg-dark " id="navbar-header">
                     <a href="" class="navbar-brand  web-logo"><img src="<?php echo get_template_directory_uri();?>/images/logo.png" alt="" ></a>
                     <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#figgin-nav">
                     <span class="navbar-toggler-icon"></span>
                     </button>
                     <div class="collapse navbar-collapse justify-content-end m-4 m-lg-0" id="figgin-nav">
                        <ul class="nav navbar-nav justify-content-lg-end text-center text-lg-left mr-4 w-100">
                           <li class="nav-item  "><a href="<?php echo get_site_url( );?> " class="nav-link ">Home</a></li>
                           <li class="nav-item  "><a href="<?php echo get_site_url( );?>/about-us" class="nav-link">About Us</a></li>

                           <!-- Services with drop down  -->


                          <li class="nav-item dropdown">
                                      <a href="<?php echo get_site_url( );?>/services" class="nav-link dropdown-toggle" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">Services</span> <span class="caret"></span></a>
                                      <ul class="dropdown-menu">
                                          <li class="dropdown">

                                            <a href="<?php echo get_site_url( );?>/services " class="dropdown-item dropdown-toggle" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">Cooling Services</span><span class="caret"></span></a>
                                              <ul class="dropdown-menu inner-submenu">
                                                  <li><a href="<?php echo get_site_url( );?>/services/a-c-tune-up/">A/C tune up</a></li>
                                                  <div class="dropdown-divider"></div>
                                                  <li><a href="<?php echo get_site_url( );?>/services/a-c-repair/">A/C repair</a></li>
                                                  <div class="dropdown-divider"></div>
                                                  <li><a href="<?php echo get_site_url( );?>/services/a-c-installation/">A/C installation</a></li>
                                                   
                                              </ul>

                                          </li>
                                          <div class="dropdown-divider"></div>
                                          <li class="dropdown">

                                            <a href="<?php echo get_site_url( );?>/services " class="dropdown-item dropdown-toggle" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">Heating Services</span><span class="caret"></span></a>
                                              <ul class="dropdown-menu  inner-submenu">
                                                  <li><a href="<?php echo get_site_url( );?>/services/furnace-tune-ups/">Furnace tune ups</a></li>
                                                  <div class="dropdown-divider"></div>
                                                  <li><a href="<?php echo get_site_url( );?>/services/furnace-repair/">Furnace repair</a></li>
                                                  <div class="dropdown-divider"></div>
                                                  <li><a href="<?php echo get_site_url( );?>/services/furnace-installation/">Furnace installation</a></li>
                                                   
                                              </ul>

                                          </li>
                                          <div class="dropdown-divider"></div>
                                          <li class="dropdown">

                                            <a href="<?php echo get_site_url( );?>/home-air-quality/" class="dropdown-item dropdown-toggle" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">Air Quality Services</span><span class="caret"></span></a>
                                              <ul class="dropdown-menu  inner-submenu">
                                                  <li><a href="<?php echo get_site_url( );?>/services/humidification/">Humidification</a></li>
                                                  <div class="dropdown-divider"></div>
                                                  <li><a href="<?php echo get_site_url( );?>/services/air-purifiers/">Air purifiers</a></li>
                                                  <div class="dropdown-divider"></div>
                                                  <li><a href="<?php echo get_site_url( );?>/services/air-cleaners/">Air cleaners</a></li>
                                                  <div class="dropdown-divider"></div>
                                                  <li><a href="<?php echo get_site_url( );?>/services/thermostats/">Thermostats </a></li>
                                                  <div class="dropdown-divider"></div>
                                                  <li><a href="<?php echo get_site_url( );?>/services/filtration/">Filtration </a></li>
                                                   
                                              </ul>

                                          </li>
                                          <div class="dropdown-divider"></div>
                                          <li class="dropdown">

                                            <a href="<?php echo get_site_url( );?>/other-services/" class="dropdown-item dropdown-toggle" data-hover="dropdown" role="button" aria-haspopup="true" aria-expanded="true"> <span class="nav-label">Other Services</span><span class="caret"></span></a>
                                              <ul class="dropdown-menu inner-submenu">
                                                  <li><a href="<?php echo get_site_url( );?>/services/heat-pumps/">Heat Pumps</a></li>
                                                  <li><a href="<?php echo get_site_url( );?>/services/ductless-systems/">Ductless Systems</a></li> 
                                                   
                                              </ul>

                                          </li>
                                      </ul>
                                  </li>


                            <!-- ====== End with services dropdown ========       -->

                           <li class="nav-item "><a href="<?php echo get_site_url( );?>/faq" class="nav-link">Faq</a></li>
                           <li class="nav-item "><a href="<?php echo get_site_url( );?>/contact-us" class="nav-link">Contact</a></li>
                        </ul>
                        <a href="#" class="btn donate-btn mt-lg-0 mt-3 free-est-btn">Free Estimate</a>
                     </div>
                  </nav>
               </div>
            </div>
         </div>
      </header>



 